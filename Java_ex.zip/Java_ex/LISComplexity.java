import java.util.*;

public class LISComplexity {

    static long comparisons = 0; // đếm số phép so sánh

    // LIS O(n log n)
    static int lis(int[] a) {
        int n = a.length;
        int[] tail = new int[n];
        int size = 0;

        for (int x : a) {
            int l = 0, r = size;

            // binary search
            while (l < r) {
                int mid = (l + r) / 2;
                comparisons++;
                if (tail[mid] < x)
                    l = mid + 1;
                else
                    r = mid;
            }

            tail[l] = x;
            if (l == size) size++;
        }
        return size;
    }

    public static void main(String[] args) {
        int N = 1_000_000;
        int[] arr = new int[N];
        Random rand = new Random(42);

        for (int i = 0; i < N; i++)
            arr[i] = rand.nextInt(N);

        long start = System.nanoTime();
        int length = lis(arr);
        long time = System.nanoTime() - start;

        System.out.println("===== LIS O(n log n) =====");
        System.out.println("Array size       : " + N);
        System.out.println("LIS length       : " + length);
        System.out.println("Comparisons      : " + comparisons);
        System.out.println("Time             : " + time / 1_000_000 + " ms");

        double logN = Math.log(N) / Math.log(2);
        System.out.printf("n * log2(n)      : %.0f%n", N * logN);
    }
}