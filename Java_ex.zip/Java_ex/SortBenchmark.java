import java.util.*;

class SortBenchmark {
    static boolean isSorted(int[] a) {
        for (int i = 1; i < a.length; i++)
            if (a[i - 1] > a[i])
                return false;
        return true;
    }

    static void quickSort(int[] a, int l, int r) {
        if (l >= r)
            return;

        int pivot = a[(l + r) / 2];
        int i = l, j = r;

        while (i <= j) {
            while (a[i] < pivot)
                i++;
            while (a[j] > pivot)
                j--;

            if (i <= j) {
                int tmp = a[i];
                a[i] = a[j];
                a[j] = tmp;
                i++;
                j--;
            }
        }

        if (l < j)
            quickSort(a, l, j);
        if (i < r)
            quickSort(a, i, r);
    }

    static void mergeSort(int[] a, int l, int r, int[] tmp) {
        if (l >= r)
            return;

        int mid = (l + r) / 2;
        mergeSort(a, l, mid, tmp);
        mergeSort(a, mid + 1, r, tmp);
        merge(a, l, mid, r, tmp);
    }

    static void merge(int[] a, int l, int m, int r, int[] tmp) {
        int i = l, j = m + 1, k = l;

        while (i <= m && j <= r)
            tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];

        while (i <= m)
            tmp[k++] = a[i++];
        while (j <= r)
            tmp[k++] = a[j++];

        for (i = l; i <= r; i++)
            a[i] = tmp[i];
    }

    public static void main(String[] args) {
        int N = 1_000_000;
        int[] original = new int[N];
        Random rand = new Random(42);

        for (int i = 0; i < N; i++)
            original[i] = rand.nextInt();

        int[] arrQuick = original.clone();
        int[] arrMerge = original.clone();

        long start = System.nanoTime();
        quickSort(arrQuick, 0, arrQuick.length - 1);
        long quickTime = System.nanoTime() - start;

        int[] tmp = new int[N];
        start = System.nanoTime();
        mergeSort(arrMerge, 0, arrMerge.length - 1, tmp);
        long mergeTime = System.nanoTime() - start;

        System.out.println("===== RESULT (1,000,000 elements) =====");
        System.out.println("QuickSort : " + quickTime / 1_000_000 + " ms");
        System.out.println("MergeSort : " + mergeTime / 1_000_000 + " ms");

        System.out.println("Sorted OK? " +
                (isSorted(arrQuick) && isSorted(arrMerge)));
    }
}