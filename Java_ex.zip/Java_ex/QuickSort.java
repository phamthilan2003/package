import java.util.Arrays;

public class QuickSort {

    static void quickSort(int[] a, int l, int r) {
        if (l >= r) return;

        int pivot = a[(l + r) / 2];
        int i = l, j = r;

        while (i <= j) {
            while (a[i] < pivot) i++;
            while (a[j] > pivot) j--;

            if (i <= j) {
                int tmp = a[i];
                a[i] = a[j];
                a[j] = tmp;
                i++;
                j--;
            }
        }

        quickSort(a, l, j);
        quickSort(a, i, r);
    }

    public static void main(String[] args) {
        int[] arr = {8, 3, 1, 7, 0, 10, 2};

        System.out.println("Before sort:");
        System.out.println(Arrays.toString(arr));

        quickSort(arr, 0, arr.length - 1);

        System.out.println("After sort:");
        System.out.println(Arrays.toString(arr));
    }
}