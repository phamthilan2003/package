import java.util.Arrays;

public class MergeSort{

    static void mergeSort(int[] a, int l, int r) {
        if (l >= r) return;

        int mid = (l + r) / 2;
        mergeSort(a, l, mid);
        mergeSort(a, mid + 1, r);
        merge(a, l, mid, r);
    }

    static void merge(int[] a, int l, int m, int r) {
        int[] tmp = new int[r - l + 1];
        int i = l, j = m + 1, k = 0;

        while (i <= m && j <= r)
            tmp[k++] = a[i] <= a[j] ? a[i++] : a[j++];

        while (i <= m) tmp[k++] = a[i++];
        while (j <= r) tmp[k++] = a[j++];

        for (i = 0; i < tmp.length; i++)
            a[l + i] = tmp[i];
    }

    public static void main(String[] args) {
        int[] arr = {8, 3, 1, 7, 0, 10, 2};

        System.out.println("Before sort:");
        System.out.println(Arrays.toString(arr));

        mergeSort(arr, 0, arr.length - 1);

        System.out.println("After sort:");
        System.out.println(Arrays.toString(arr));
    }
}