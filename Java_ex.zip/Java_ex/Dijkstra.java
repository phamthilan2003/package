import java.util.*;

class Dijkstra {

    static class Edge {
        int to, weight;

        Edge(int t, int w) {
            to = t;
            weight = w;
        }
    }

    static class Node implements Comparable<Node> {
        int v, dist;

        Node(int v, int d) {
            this.v = v;
            this.dist = d;
        }

        public int compareTo(Node o) {
            return this.dist - o.dist;
        }
    }

    static void dijkstra(int n, List<Edge>[] graph, int src) {
        int[] dist = new int[n];
        Arrays.fill(dist, Integer.MAX_VALUE);

        PriorityQueue<Node> pq = new PriorityQueue<>();
        dist[src] = 0;
        pq.add(new Node(src, 0));

        while (!pq.isEmpty()) {
            Node cur = pq.poll();
            int u = cur.v;

            if (cur.dist > dist[u])
                continue;

            for (Edge e : graph[u]) {
                if (dist[e.to] > dist[u] + e.weight) {
                    dist[e.to] = dist[u] + e.weight;
                    pq.add(new Node(e.to, dist[e.to]));
                }
            }
        }

        for (int i = 0; i < n; i++) {
            System.out.println("Dist from " + src + " to " + i + " = " + dist[i]);
        }
    }

    public static void main(String[] args) {
        int n = 4;

        List<Edge>[] graph = new ArrayList[n];
        for (int i = 0; i < n; i++) {
            graph[i] = new ArrayList<>();
        }

        graph[0].add(new Edge(1, 4));
        graph[0].add(new Edge(2, 1));
        graph[2].add(new Edge(1, 2));
        graph[1].add(new Edge(3, 1));
        graph[2].add(new Edge(3, 5));

        dijkstra(n, graph, 0);
    }
}